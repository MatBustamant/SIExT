/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author Usuario
 */
public class Averio {
    private int ID_Averio;
    private int ID_Producto;
    private LocalDate Fecha_Averio;
    private LocalTime Hora_Averio;

    public Averio(int ID_Averio, int ID_Producto, LocalDate Fecha_Averio, LocalTime Hora_Averio) {
        this.ID_Averio = ID_Averio;
        this.ID_Producto = ID_Producto;
        this.Fecha_Averio = Fecha_Averio;
        this.Hora_Averio = Hora_Averio;
    }

    public int getID_Averio() {
        return ID_Averio;
    }

    public void setID_Averio(int ID_Averio) {
        this.ID_Averio = ID_Averio;
    }

    public int getID_Producto() {
        return ID_Producto;
    }

    public void setID_Producto(int ID_Producto) {
        this.ID_Producto = ID_Producto;
    }

    public LocalDate getFecha_Averio() {
        return Fecha_Averio;
    }

    public void setFecha_Averio(LocalDate Fecha_Averio) {
        this.Fecha_Averio = Fecha_Averio;
    }

    public LocalTime getHora_Averio() {
        return Hora_Averio;
    }

    public void setHora_Averio(LocalTime Hora_Averio) {
        this.Hora_Averio = Hora_Averio;
    }
    
    
 
}
