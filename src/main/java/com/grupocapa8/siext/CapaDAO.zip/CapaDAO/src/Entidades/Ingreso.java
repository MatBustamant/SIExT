/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author oveja
 */
public class Ingreso {
    
    private int ID_Ingreso;
    private LocalDate Fecha_Ingreso;
    private LocalTime Hora_Ingreso;
    private int Cantidad;
    private int ID_Producto;

    public Ingreso(int ID_Ingreso, LocalDate Fecha_Ingreso, LocalTime Hora_Ingreso, int Cantidad, int ID_Producto) {
        this.ID_Ingreso = ID_Ingreso;
        this.Fecha_Ingreso = Fecha_Ingreso;
        this.Hora_Ingreso = Hora_Ingreso;
        this.Cantidad = Cantidad;
        this.ID_Producto = ID_Producto;
    }

    public int getID_Ingreso() {
        return ID_Ingreso;
    }

    public void setID_Ingreso(int ID_Ingreso) {
        this.ID_Ingreso = ID_Ingreso;
    }

    public LocalDate getFecha_Ingreso() {
        return Fecha_Ingreso;
    }

    public void setFecha_Ingreso(LocalDate Fecha_Ingreso) {
        this.Fecha_Ingreso = Fecha_Ingreso;
    }

    public LocalTime getHora_Ingreso() {
        return Hora_Ingreso;
    }

    public void setHora_Ingreso(LocalTime Hora_Ingreso) {
        this.Hora_Ingreso = Hora_Ingreso;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public int getID_Producto() {
        return ID_Producto;
    }

    public void setID_Producto(int ID_Producto) {
        this.ID_Producto = ID_Producto;
    }
    
    
    
}
