/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author Usuario
 */
public class Detalle_Despiece {
    private int ID_Despiece;
    private int ID_Producto;

    public Detalle_Despiece(int ID_Despiece, int ID_Producto) {
        this.ID_Despiece = ID_Despiece;
        this.ID_Producto = ID_Producto;
    }

    public int getID_Despiece() {
        return ID_Despiece;
    }

    public void setID_Despiece(int ID_Despiece) {
        this.ID_Despiece = ID_Despiece;
    }

    public int getID_Producto() {
        return ID_Producto;
    }

    public void setID_Producto(int ID_Producto) {
        this.ID_Producto = ID_Producto;
    }
    
    
}
