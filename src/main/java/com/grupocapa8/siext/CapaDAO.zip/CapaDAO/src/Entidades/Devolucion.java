/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author Usuario
 */
public class Devolucion {
    
    private int ID_Devolucion;
    private int ID_Producto;
    private LocalDate Fecha_Devolucion;
    private LocalTime Hora_Devolucion;

    public Devolucion(int ID_Devolucion, int ID_Producto, LocalDate Fecha_Devolucion, LocalTime Hora_Devolucion) {
        this.ID_Devolucion = ID_Devolucion;
        this.ID_Producto = ID_Producto;
        this.Fecha_Devolucion = Fecha_Devolucion;
        this.Hora_Devolucion = Hora_Devolucion;
    }

    public int getID_Devolucion() {
        return ID_Devolucion;
    }

    public void setID_Devolucion(int ID_Devolucion) {
        this.ID_Devolucion = ID_Devolucion;
    }

    public int getID_Producto() {
        return ID_Producto;
    }

    public void setID_Producto(int ID_Producto) {
        this.ID_Producto = ID_Producto;
    }

    public LocalDate getFecha_Devolucion() {
        return Fecha_Devolucion;
    }

    public void setFecha_Devolucion(LocalDate Fecha_Devolucion) {
        this.Fecha_Devolucion = Fecha_Devolucion;
    }

    public LocalTime getHora_Devolucion() {
        return Hora_Devolucion;
    }

    public void setHora_Devolucion(LocalTime Hora_Devolucion) {
        this.Hora_Devolucion = Hora_Devolucion;
    }
    
    
}
