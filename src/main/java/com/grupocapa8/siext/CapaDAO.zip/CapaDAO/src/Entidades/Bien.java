/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author Usuario
 */
public class Bien {
    private int ID_Bien;
    private String Estado;
    private String Ubicacion;

    public Bien(int ID_Bien, String estado, String ubicacion) {
        this.ID_Bien = ID_Bien;
        this.Estado = estado;
        this.Ubicacion = ubicacion;
    }
    
    

    public int getID_Bien() {
        return ID_Bien;
    }

    public void setID_Bien(int ID_Bien) {
        this.ID_Bien = ID_Bien;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String estado) {
        this.Estado = estado;
    }

    public String getUbicacion() {
        return Ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.Ubicacion = ubicacion;
    }
    
    
}
