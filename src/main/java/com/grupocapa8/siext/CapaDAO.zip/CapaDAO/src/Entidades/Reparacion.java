/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author oveja
 */

import java.time.LocalDate;
import java.time.LocalTime;

public class Reparacion {
    private int ID_Reparacion;
    private int ID_Producto;
    private LocalDate Fecha_Reparacion;
    private LocalTime Hora_Reparacion;

    public Reparacion(int ID_Reparacion, int ID_Producto, LocalDate Fecha_Reparacion, LocalTime Hora_Reparacion) {
        this.ID_Reparacion = ID_Reparacion;
        this.ID_Producto = ID_Producto;
        this.Fecha_Reparacion = Fecha_Reparacion;
        this.Hora_Reparacion = Hora_Reparacion;
    }

    public int getID_Reparacion() {
        return ID_Reparacion;
    }

    public void setID_Reparacion(int ID_Reparacion) {
        this.ID_Reparacion = ID_Reparacion;
    }

    public int getID_Producto() {
        return ID_Producto;
    }

    public void setID_Producto(int ID_Producto) {
        this.ID_Producto = ID_Producto;
    }

    public LocalDate getFecha_Reparacion() {
        return Fecha_Reparacion;
    }

    public void setFecha_Reparacion(LocalDate Fecha_Reparacion) {
        this.Fecha_Reparacion = Fecha_Reparacion;
    }

    public LocalTime getHora_Reparacion() {
        return Hora_Reparacion;
    }

    public void setHora_Reparacion(LocalTime Hora_Reparacion) {
        this.Hora_Reparacion = Hora_Reparacion;
    }
    
    
    
}
