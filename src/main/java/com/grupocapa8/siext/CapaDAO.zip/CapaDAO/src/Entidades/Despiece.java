/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author Usuario
 */
public class Despiece {
    private int ID_Despiece;
    private int ID_Producto;
    private LocalDate Fecha_Despiece;
    private LocalTime Hora_Despiece;

    public Despiece(int ID_Despiece, int ID_Producto, LocalDate Fecha_Ingreso, LocalTime Hora_Ingreso) {
        this.ID_Despiece = ID_Despiece;
        this.ID_Producto = ID_Producto;
        this.Fecha_Despiece = Fecha_Ingreso;
        this.Hora_Despiece = Hora_Ingreso;
    }

    public int getID_Despiece() {
        return ID_Despiece;
    }

    public void setID_Despiece(int ID_Despiece) {
        this.ID_Despiece = ID_Despiece;
    }

    public int getID_Producto() {
        return ID_Producto;
    }

    public void setID_Producto(int ID_Producto) {
        this.ID_Producto = ID_Producto;
    }

    public LocalDate getFecha_Ingreso() {
        return Fecha_Despiece;
    }

    public void setFecha_Ingreso(LocalDate Fecha_Ingreso) {
        this.Fecha_Despiece = Fecha_Ingreso;
    }

    public LocalTime getHora_Ingreso() {
        return Hora_Despiece;
    }

    public void setHora_Ingreso(LocalTime Hora_Ingreso) {
        this.Hora_Despiece = Hora_Ingreso;
    }
    
    
    
}
