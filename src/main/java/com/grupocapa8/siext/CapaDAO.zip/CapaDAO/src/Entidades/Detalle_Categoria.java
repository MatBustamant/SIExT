/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author oveja
 */
public class Detalle_Categoria {
    private int ID_Categoria;
    private int MinReposicion;
    private int Stock;

    public Detalle_Categoria(int ID_Categoria, int MinReposicion, int Stock) {
        this.ID_Categoria = ID_Categoria;
        this.MinReposicion = MinReposicion;
        this.Stock = Stock;
    }

    public int getID_Categoria() {
        return ID_Categoria;
    }

    public void setID_Categoria(int ID_Categoria) {
        this.ID_Categoria = ID_Categoria;
    }

    public int getMinReposicion() {
        return MinReposicion;
    }

    public void setMinReposicion(int MinReposicion) {
        this.MinReposicion = MinReposicion;
    }

    public int getStock() {
        return Stock;
    }

    public void setStock(int Stock) {
        this.Stock = Stock;
    }
    
    
}
