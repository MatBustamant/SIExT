/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author Usuario
 */
public class Detalle_Salida {
    private int ID_Salida;
    private int ID_Producto;
    private int Cantidad;

    public Detalle_Salida(int ID_Salida, int ID_Producto, int Cantidad) {
        this.ID_Salida = ID_Salida;
        this.ID_Producto = ID_Producto;
        this.Cantidad = Cantidad;
    }

    public int getID_Salida() {
        return ID_Salida;
    }

    public void setID_Salida(int ID_Salida) {
        this.ID_Salida = ID_Salida;
    }

    public int getID_Producto() {
        return ID_Producto;
    }

    public void setID_Producto(int ID_Producto) {
        this.ID_Producto = ID_Producto;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }
    
    
    
}
