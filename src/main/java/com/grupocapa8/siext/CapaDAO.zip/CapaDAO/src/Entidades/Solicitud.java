/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.time.LocalDate;

/**
 *
 * @author oveja
 */
public class Solicitud {
    private int Num_Solicitud;
    private int Legajo_Solicitante;
    private LocalDate Fecha_inicio;
    private String Destino;
    private String Estado;
    private String Descripcion;

    
    public Solicitud(int Num_Solicitud, int Legajo_Solicitante, LocalDate Fecha_inicio, String Destino, String Estado, String Descripcion) {
        this.Num_Solicitud = Num_Solicitud;
        this.Legajo_Solicitante = Legajo_Solicitante;
        this.Fecha_inicio = Fecha_inicio;
        this.Destino = Destino;
        this.Estado = Estado;
        this.Descripcion = Descripcion;
    }

    public int getNum_Solicitud() {
        return Num_Solicitud;
    }

    public void setNum_Solicitud(int Num_Solicitud) {
        this.Num_Solicitud = Num_Solicitud;
    }
    
    public int getLegajo_Solicitante() {
        return Legajo_Solicitante;
    }

    public void setLegajo_Solicitante(int Legajo_Solicitante) {
        this.Legajo_Solicitante = Legajo_Solicitante;
    }
    

    public LocalDate getFecha_inicio() {
        return Fecha_inicio;
    }

    public void setFecha_inicio(LocalDate Fecha_inicio) {
        this.Fecha_inicio = Fecha_inicio;
    }

    public String getDestino() {
        return Destino;
    }

    public void setDestino(String Destino) {
        this.Destino = Destino;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    
    
    
}
