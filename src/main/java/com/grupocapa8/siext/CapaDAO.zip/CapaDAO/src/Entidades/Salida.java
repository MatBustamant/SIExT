/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author Usuario
 */
public class Salida {
    private int ID_Salida;
    private int Num_Solicitud;
    private int Legajo_Retiro;
    private String Destino;
    private LocalDate Fecha_Salida;
    private LocalTime Horario_Salida;

    public Salida(int ID_Salida, int Num_Solicitud, int Legajo_Retiro, String Destino, LocalDate Fecha_Salida, LocalTime Horario_Salida) {
        this.ID_Salida = ID_Salida;
        this.Num_Solicitud = Num_Solicitud;
        this.Legajo_Retiro = Legajo_Retiro;
        this.Destino = Destino;
        this.Fecha_Salida = Fecha_Salida;
        this.Horario_Salida = Horario_Salida;
    }

    public int getID_Salida() {
        return ID_Salida;
    }

    public void setID_Salida(int ID_Salida) {
        this.ID_Salida = ID_Salida;
    }

    public int getNum_Solicitud() {
        return Num_Solicitud;
    }

    public void setNum_Solicitud(int Num_Solicitud) {
        this.Num_Solicitud = Num_Solicitud;
    }

    public int getLegajo_Retiro() {
        return Legajo_Retiro;
    }

    public void setLegajo_Retiro(int Legajo_Retiro) {
        this.Legajo_Retiro = Legajo_Retiro;
    }

    public String getDestino() {
        return Destino;
    }

    public void setDestino(String Destino) {
        this.Destino = Destino;
    }

    public LocalDate getFecha_Salida() {
        return Fecha_Salida;
    }

    public void setFecha_Salida(LocalDate Fecha_Salida) {
        this.Fecha_Salida = Fecha_Salida;
    }

    public LocalTime getHorario_Salida() {
        return Horario_Salida;
    }

    public void setHorario_Salida(LocalTime Horario_Salida) {
        this.Horario_Salida = Horario_Salida;
    }
    
    
}
    
    
